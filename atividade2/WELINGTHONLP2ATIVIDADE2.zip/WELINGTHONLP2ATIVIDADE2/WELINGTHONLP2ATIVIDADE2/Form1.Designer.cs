﻿namespace WELINGTHONLP2ATIVIDADE2
{
    partial class Ds
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbNum1 = new System.Windows.Forms.Label();
            this.LbResul = new System.Windows.Forms.Label();
            this.LbNum2 = new System.Windows.Forms.Label();
            this.BtMais = new System.Windows.Forms.Button();
            this.BtMenos = new System.Windows.Forms.Button();
            this.BtVezes = new System.Windows.Forms.Button();
            this.BtDiv = new System.Windows.Forms.Button();
            this.BtSair = new System.Windows.Forms.Button();
            this.BtLimpar = new System.Windows.Forms.Button();
            this.textNum1 = new System.Windows.Forms.TextBox();
            this.textResult = new System.Windows.Forms.TextBox();
            this.textNum2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LbNum1
            // 
            this.LbNum1.AutoSize = true;
            this.LbNum1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbNum1.Location = new System.Drawing.Point(24, 33);
            this.LbNum1.Name = "LbNum1";
            this.LbNum1.Size = new System.Drawing.Size(121, 33);
            this.LbNum1.TabIndex = 0;
            this.LbNum1.Text = "Numero 1";
            // 
            // LbResul
            // 
            this.LbResul.AutoSize = true;
            this.LbResul.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbResul.Location = new System.Drawing.Point(24, 205);
            this.LbResul.Name = "LbResul";
            this.LbResul.Size = new System.Drawing.Size(127, 33);
            this.LbResul.TabIndex = 1;
            this.LbResul.Text = "Resultado";
            // 
            // LbNum2
            // 
            this.LbNum2.AutoSize = true;
            this.LbNum2.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbNum2.Location = new System.Drawing.Point(24, 89);
            this.LbNum2.Name = "LbNum2";
            this.LbNum2.Size = new System.Drawing.Size(121, 33);
            this.LbNum2.TabIndex = 2;
            this.LbNum2.Text = "Numero 2";
            // 
            // BtMais
            // 
            this.BtMais.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtMais.Location = new System.Drawing.Point(40, 301);
            this.BtMais.Name = "BtMais";
            this.BtMais.Size = new System.Drawing.Size(111, 76);
            this.BtMais.TabIndex = 3;
            this.BtMais.Text = "+";
            this.BtMais.UseVisualStyleBackColor = true;
            this.BtMais.Click += new System.EventHandler(this.BtMais_Click);
            // 
            // BtMenos
            // 
            this.BtMenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtMenos.Location = new System.Drawing.Point(241, 301);
            this.BtMenos.Name = "BtMenos";
            this.BtMenos.Size = new System.Drawing.Size(111, 76);
            this.BtMenos.TabIndex = 4;
            this.BtMenos.Text = "-";
            this.BtMenos.UseVisualStyleBackColor = true;
            this.BtMenos.Click += new System.EventHandler(this.BtMenos_Click);
            // 
            // BtVezes
            // 
            this.BtVezes.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtVezes.Location = new System.Drawing.Point(442, 301);
            this.BtVezes.Name = "BtVezes";
            this.BtVezes.Size = new System.Drawing.Size(111, 76);
            this.BtVezes.TabIndex = 5;
            this.BtVezes.Text = "*";
            this.BtVezes.UseVisualStyleBackColor = true;
            this.BtVezes.Click += new System.EventHandler(this.BtVezes_Click);
            // 
            // BtDiv
            // 
            this.BtDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtDiv.Location = new System.Drawing.Point(643, 301);
            this.BtDiv.Name = "BtDiv";
            this.BtDiv.Size = new System.Drawing.Size(111, 76);
            this.BtDiv.TabIndex = 6;
            this.BtDiv.Text = "/";
            this.BtDiv.UseVisualStyleBackColor = true;
            this.BtDiv.Click += new System.EventHandler(this.BtDiv_Click);
            // 
            // BtSair
            // 
            this.BtSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtSair.Location = new System.Drawing.Point(612, 180);
            this.BtSair.Name = "BtSair";
            this.BtSair.Size = new System.Drawing.Size(176, 58);
            this.BtSair.TabIndex = 7;
            this.BtSair.Text = "Sair ";
            this.BtSair.UseVisualStyleBackColor = true;
            this.BtSair.Click += new System.EventHandler(this.BtSair_Click_1);
            // 
            // BtLimpar
            // 
            this.BtLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtLimpar.Location = new System.Drawing.Point(612, 33);
            this.BtLimpar.Name = "BtLimpar";
            this.BtLimpar.Size = new System.Drawing.Size(176, 58);
            this.BtLimpar.TabIndex = 8;
            this.BtLimpar.Text = "Limpar";
            this.BtLimpar.UseVisualStyleBackColor = true;
            this.BtLimpar.Click += new System.EventHandler(this.BtLimpar_Click);
            // 
            // textNum1
            // 
            this.textNum1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNum1.Location = new System.Drawing.Point(241, 33);
            this.textNum1.Name = "textNum1";
            this.textNum1.Size = new System.Drawing.Size(312, 38);
            this.textNum1.TabIndex = 9;
            this.textNum1.Validated += new System.EventHandler(this.textNum1_Validated_1);
            // 
            // textResult
            // 
            this.textResult.Enabled = false;
            this.textResult.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textResult.Location = new System.Drawing.Point(244, 200);
            this.textResult.Name = "textResult";
            this.textResult.Size = new System.Drawing.Size(312, 38);
            this.textResult.TabIndex = 10;
            this.textResult.TextChanged += new System.EventHandler(this.textResult_TextChanged);
            // 
            // textNum2
            // 
            this.textNum2.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNum2.Location = new System.Drawing.Point(244, 84);
            this.textNum2.Name = "textNum2";
            this.textNum2.Size = new System.Drawing.Size(312, 38);
            this.textNum2.TabIndex = 11;
            this.textNum2.TextChanged += new System.EventHandler(this.textNum2_TextChanged);
            // 
            // Ds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textNum2);
            this.Controls.Add(this.textResult);
            this.Controls.Add(this.textNum1);
            this.Controls.Add(this.BtLimpar);
            this.Controls.Add(this.BtSair);
            this.Controls.Add(this.BtDiv);
            this.Controls.Add(this.BtVezes);
            this.Controls.Add(this.BtMenos);
            this.Controls.Add(this.BtMais);
            this.Controls.Add(this.LbNum2);
            this.Controls.Add(this.LbResul);
            this.Controls.Add(this.LbNum1);
            this.Name = "Ds";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LbNum1;
        private System.Windows.Forms.Label LbResul;
        private System.Windows.Forms.Label LbNum2;
        private System.Windows.Forms.Button BtMais;
        private System.Windows.Forms.Button BtMenos;
        private System.Windows.Forms.Button BtVezes;
        private System.Windows.Forms.Button BtDiv;
        private System.Windows.Forms.Button BtSair;
        private System.Windows.Forms.Button BtLimpar;
        private System.Windows.Forms.TextBox textNum1;
        private System.Windows.Forms.TextBox textResult;
        private System.Windows.Forms.TextBox textNum2;
    }
}

