﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WELINGTHONLP2ATIVIDADE2
{
    public partial class Ds : Form
    {
        double n1, n2, resultado;
        public Ds()
        {
            InitializeComponent();
        }

        private void textNum1_Validated_1(object sender, EventArgs e)
        {
            if (!double.TryParse(textNum1.Text, out n1))
                {

                }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textNum2_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(textNum2.Text, out n2))
                {

                }
        }

        private void textResult_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(textResult.Text, out resultado))
            {

            }
        }

        private void BtSair_Click(object sender, EventArgs e)
        {
           
        }

        private void BtLimpar_Click(object sender, EventArgs e)
        {
            textNum1.Clear();
            textNum2.Clear();
            textResult.Clear();
        }

        private void BtMais_Click(object sender, EventArgs e)
        {
            resultado = n1 + n2;
            textResult.Text = resultado.ToString();
        }

        private void BtMenos_Click(object sender, EventArgs e)
        {
            resultado = n1 - n2;
            textResult.Text = resultado.ToString();
        }

        private void BtVezes_Click(object sender, EventArgs e)
        {
            resultado = n1 * n2;
            textResult.Text = resultado.ToString();
        }

        private void BtDiv_Click(object sender, EventArgs e)
        {
            if (n2==0)
            {
                MessageBox.Show("Não é possivel dividir por 0");
                textNum2.Focus();
            }
            else
            {
                resultado = n1 / n2;
                textResult.Text = resultado.ToString();

            }
        }

        private int SendKeys(string v)
        {
            throw new NotImplementedException();
        }

        private void BtSair_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void textNum1_Validated(object sender, EventArgs e)
        {

        }

        private void textNum1_Validating(object sender, CancelEventArgs e)
        {

        }
    }
}
